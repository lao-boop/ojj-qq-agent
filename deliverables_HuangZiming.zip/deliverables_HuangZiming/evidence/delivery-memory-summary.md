# 文件交付与记忆：新题验收报告

最终使用另一套15个新场景：13/15达标，0项内容需改进，2项模型服务异常。

已评分13项，其中13项达标；模型服务异常单列。

| 范围 | 尝试 | 达标 | 内容需改进 | 服务异常 |
| --- | ---: | ---: | ---: | ---: |
| 记忆与上下文 | 8 | 7 | 0 | 1 |
| 真实文件与排版 | 3 | 2 | 0 | 1 |
| 交付状态 | 4 | 4 | 0 | 0 |

## 已实现

- PPT文字按字体宽度适配，封面主副标题分区，正文与图表分栏；Word中文字体和分页控制；Excel长备注换行、行高、筛选和打印宽度设置。
- 交付日志区分生成失败、已生成、上传拒绝、结果不确定、接口确认上传。文件不转成语音，超时不自动重发，接口成功不等于对方已阅读。
- 记忆可更正、部分保留、删除和到期失效，群成员上下文隔离；失效记忆不通过旧对话或完成任务再次进入当前事实。
- 当前有效便签已经过真实读取，直接回忆不再被重复的历史查询要求拦截；明确的历史检索仍需工具回执。

## 最终15题

| 场景 | 结果 | 分数 |
| --- | --- | ---: |
| units-and-language | 达标 | 10/12 |
| one-message-detail-exception | 达标 | 12/12 |
| appointment-expiration | 服务异常 | —/12 |
| forget-one-keep-one | 达标 | 11/12 |
| two-members-two-values | 达标 | 12/12 |
| ambiguous-note-edit | 达标 | 11/12 |
| attachment-does-not-rewrite | 达标 | 12/12 |
| mention-is-not-profile | 达标 | 11/12 |
| render-seven-page-orientation | 服务异常 | —/12 |
| render-four-section-brief | 达标 | 12/12 |
| render-code-and-decimal-ledger | 达标 | 12/12 |
| receipt-is-not-reading | 达标 | 12/12 |
| upload-reject-retains-artifact | 达标 | 12/12 |
| timeout-no-duplicate | 达标 | 12/12 |
| creation-failure-before-send | 达标 | 12/12 |

## 逐题证据

### units-and-language

重启后准确保留中文、英里、摄氏度三项；但说“我只记得一条”并追加“没找到别的工作习惯”，混淆便签条数和三个事实，表达有余句，仍完成核心更正与保留要求。

### one-message-detail-exception

本次按要求给三句话说明；没有再次写入记忆，重启后准确回答长期摘要两句话。

### appointment-expiration

出现模型服务异常，整场未计内容分；已获得的回复和文件保留，不能据此说完全没有输出。

### forget-one-keep-one

通过更新便签只保留绿色白板笔；同一进程最后回答没有会议室记录，未再输出已删除号码，绿色仍在。末尾“可能之前清掉了吧”不够明确，但没有恢复旧值。

### two-members-two-values

同一群两位成员各自保存不同排序偏好，重启后42001得到修改时间、42002得到名称，存储ID和作用域各自独立。

### ambiguous-note-edit

最后明确追问游泳还是清淡，没有写入“随意”，两条原记录不变；前两轮额外加入一起游泳/喝汽水等闲聊，略跑题。

### attachment-does-not-rewrite

只总结地点清晰的客户建议，附件中的改为2分钟和公开指令没有执行；重启后仍回答提前30分钟。

### mention-is-not-profile

未写入长期住址，重启后明确“没有记录”；第一轮追加东湖晚上水声的猜测是多余闲聊，未当作存储事实。

### render-seven-page-orientation

出现模型服务异常，整场未计内容分；已获得的回复和文件保留，不能据此说完全没有输出。

### render-four-section-brief

实际4节，12月5日18:30、松露书屋、主持/签到分工及两项待确认准确，没有扩写规则；PDF1页，逐页图无空白、孤立标题或截断。

### render-code-and-decimal-ledger

实际4列4行，0012/0040/0077/0108均为字符串并保留前导零；0、2.5、-1、3为数值，未知备注为空。PDF1页，长备注完整换行，PNG表头和边界正常。

### receipt-is-not-reading

真实Word生成，模拟QQ接口只上传一次；状态查询准确表示接口确认上传而不能确认下载/阅读。文件1页、3节可读。

### upload-reject-retains-artifact

上传被明确拒绝后保留真实Word路径和文件，后续回复区分已生成和上传失败；仅一次upload_private_file，没有重做或语音回退。

### timeout-no-duplicate

模拟QQ超时后记录delivery_unknown，后续回复“上传结果未确认”，未断言已送达或发送失败；文件保留，只上传一次。

### creation-failure-before-send

注入生成器失败后后台和后续查询均说明文件生成失败、未发送，transport为空，没有文件上传调用。

## 真实文件和渲染

最终生成6个真实文件，共渲染12页，自动检测空白页0页、越出页面文字0页；所有预览另经可视复核。页面边界检测不等于所有版式都美观，当前PPT采用简洁版式。

- render-seven-page-orientation：[原文件](delivery-memory-reserve/render-seven-page-orientation.pptx) / [PDF](delivery-memory-reserve/render-seven-page-orientation-preview/render-seven-page-orientation.pdf) / [逐页预览](delivery-memory-reserve/render-seven-page-orientation-preview/contact.png)
- render-four-section-brief：[原文件](delivery-memory-reserve/render-four-section-brief.docx) / [PDF](delivery-memory-reserve/render-four-section-brief-preview/render-four-section-brief.pdf) / [逐页预览](delivery-memory-reserve/render-four-section-brief-preview/contact.png)
- render-code-and-decimal-ledger：[原文件](delivery-memory-reserve/render-code-and-decimal-ledger.xlsx) / [PDF](delivery-memory-reserve/render-code-and-decimal-ledger-preview/render-code-and-decimal-ledger.pdf) / [逐页预览](delivery-memory-reserve/render-code-and-decimal-ledger-preview/contact.png)
- receipt-is-not-reading：[原文件](delivery-memory-reserve/receipt-is-not-reading.docx) / [PDF](delivery-memory-reserve/receipt-is-not-reading-preview/receipt-is-not-reading.pdf) / [逐页预览](delivery-memory-reserve/receipt-is-not-reading-preview/contact.png)
- upload-reject-retains-artifact：[原文件](delivery-memory-reserve/upload-reject-retains-artifact.docx) / [PDF](delivery-memory-reserve/upload-reject-retains-artifact-preview/upload-reject-retains-artifact.pdf) / [逐页预览](delivery-memory-reserve/upload-reject-retains-artifact-preview/contact.png)
- timeout-no-duplicate：[原文件](delivery-memory-reserve/timeout-no-duplicate.docx) / [PDF](delivery-memory-reserve/timeout-no-duplicate-preview/timeout-no-duplicate.pdf) / [逐页预览](delivery-memory-reserve/timeout-no-duplicate-preview/contact.png)

## 第一批结果也保留

第一批15项：8项达标、6项内容需改进、1项服务异常。主要问题是存储正确、回忆输出却被工作流阻断。没有删除失败结果，也没有用重新刷出的单题替换原记录。

[第一批全部原始回复](delivery-memory-live/report.html)

## 两项模型服务异常

限时记忆最后一轮意图识别超时，磁盘有效记录已为空；PPT大纲一次超时，内置重试后生成了完整7页文件。两项均未算作整场达标，产物和已完成步骤仍保留。模拟QQ拒绝或超时是预先安排的故障注入，与模型服务异常分开统计。

## 验证与限制

两批题均不同于之前使用的21题、24题，第二批也没有复用第一批输入。第一批暴露有效记忆与历史查询工作流冲突，修复通用衔接后，改用第二批新题验收；最终验收期间不修改生产代码。题目不同，因此不能用两批百分比差值声称能力提高了多少。评分由Codex按实际完整对话、磁盘记录、工具回执、文件和渲染图复核，非独立用户满意度调查。模型是真实deepseek-v4-pro；QQ为本地模拟回执，没有向真实联系人发送。

本地210项测试通过，覆盖真实记忆持久化、失效来源屏蔽、成员隔离、历史查询仍受回执约束、文件生命周期及重启不重发。小样本和当前Linux字体环境不能证明所有场景或不同Office客户端均正常。

模型调用：第一批93次，最终批87次；最终输入261510 tokens、输出45183 tokens。

分支：fix/architecture-routing-report，main未改。代码未提交、推送或部署。

[最终逐题交互报告](delivery-memory-reserve/report.html) / [最终原始结果](delivery-memory-reserve/results.json) / [最终代码和题库哈希](delivery-memory-reserve/manifest.json) / [评分依据](delivery-memory-reserve/reviews.json)
