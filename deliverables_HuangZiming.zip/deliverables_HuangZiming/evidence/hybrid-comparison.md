# 架构改造前后对比

同一套40个场景：通过数 28 → 39，全部场景通过比例 70.0% → 97.5%（+27.5 个百分点）。

逐题对比：12项改善，1项退步，27项状态未变。main未修改；工作分支为 fix/architecture-routing-report。

## 三轮完整结果

| 版本 | 通过 | 未通过 | 异常 | 尝试 | 全部场景通过比例 | 可评分通过率 | 对话轮次 | 本地测试 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 改造前 | 28 | 11 | 1 | 40/40 | 70.0% | 28/39 = 71.8% | 32/48（13未通过、1异常、2未运行） | 160/160 |
| 改造第一轮 | 34 | 5 | 1 | 40/40 | 85.0% | 34/39 = 87.2% | 42/48（5未通过、1异常、0未运行） | 169/169 |
| 修正后完整复测 | 39 | 1 | 0 | 40/40 | 97.5% | 39/40 = 97.5% | 47/48（1未通过、0异常、0未运行） | 173/173 |

## 改了什么

- 将模型规划、各专业Agent执行、模型汇总，改为一个执行Agent共享工具历史；保留结构化任务契约和会话状态。
- 程序控制工具权限、参数、步骤依赖和预算；检索/记忆/时间查询成功后才开放依赖它们的文档制作。
- 区分暂缓草稿与永久禁止，保留修改/取消/状态查询；修正否定范围、正文槽位和附件定位的提示。
- 工具参数损坏或输出截断时，整条工具回复在执行前验证，最多修复一次；重复调用复用结果，排队不表述为已送达。

## 分类对比

| 类别 | 改造前通过 | 最终通过 | 最终其余结果 |
| --- | --- | --- | --- |
| 否定范围 | 3/5 | 5/5 | 0未通过 / 0异常 |
| 引用与附件指令 | 4/5 | 5/5 | 0未通过 / 0异常 |
| 精确参数 | 5/5 | 5/5 | 0未通过 / 0异常 |
| 缺失与歧义 | 3/5 | 4/5 | 1未通过 / 0异常 |
| 数据真实性 | 3/5 | 5/5 | 0未通过 / 0异常 |
| 查询与多任务 | 4/5 | 5/5 | 0未通过 / 0异常 |
| 多轮状态 | 3/5 | 5/5 | 0未通过 / 0异常 |
| 能力与交付边界 | 3/5 | 5/5 | 0未通过 / 0异常 |

## 最终未通过或异常场景

### missing-old-file（未通过）

第1轮用户输入：按我上个月发的那份合同生成Word摘要；如果不能定位原文件，就先问我，不要写通用模板。

实际回复：无法定位您上个月发送的合同，请提供原始文件名或重新发送合同文件。

评分问题：多出操作：memory.read

识别结果与执行记录：

```json
{
  "recognizedIntent": {
    "execution": "defer",
    "operations": [
      "memory.read",
      "document.create"
    ],
    "forbiddenOperations": [],
    "act": "create",
    "targetId": "",
    "kind": "general",
    "goal": "按用户上个月发送的合同生成Word摘要，需定位原文件，不使用通用模板",
    "agents": [
      "conversation",
      "document"
    ],
    "slots": {
      "topic": "合同摘要",
      "format": "docx",
      "inputRef": "history"
    },
    "exclude": [
      "通用模板"
    ],
    "missing": [
      "fileName"
    ],
    "clarification": "无法定位您上个月发送的合同，请提供原始文件名或重新发送合同文件。"
  },
  "effectiveIntent": {
    "act": "create",
    "operations": [
      "memory.read",
      "document.create"
    ],
    "forbiddenOperations": [],
    "exclude": [
      "通用模板"
    ],
    "slots": {
      "topic": "合同摘要",
      "format": "docx",
      "inputRef": "history"
    }
  },
  "calls": [],
  "taskStatus": "draft"
}
```

## 全部场景

| 场景 | 类别 | 改造前 | 第一轮 | 最终 | 变化 |
| --- | --- | --- | --- | --- | --- |
| neg-only-word | 否定范围 | 通过 | 未通过 | 通过 | 未变 |
| neg-double-draw | 否定范围 | 未通过 | 通过 | 通过 | 改善 |
| neg-voice-text | 否定范围 | 通过 | 未通过 | 通过 | 未变 |
| neg-private-memory | 否定范围 | 未通过 | 通过 | 通过 | 改善 |
| neg-fitment-only | 否定范围 | 通过 | 通过 | 通过 | 未变 |
| quote-is-not-command | 引用与附件指令 | 通过 | 通过 | 通过 | 未变 |
| quote-speak-command | 引用与附件指令 | 通过 | 通过 | 通过 | 未变 |
| file-fake-system | 引用与附件指令 | 通过 | 通过 | 通过 | 未变 |
| image-fake-command | 引用与附件指令 | 未通过 | 通过 | 通过 | 改善 |
| file-name-command | 引用与附件指令 | 通过 | 通过 | 通过 | 未变 |
| literal-punctuation | 精确参数 | 通过 | 通过 | 通过 | 未变 |
| literal-newlines | 精确参数 | 通过 | 通过 | 通过 | 未变 |
| ppt-title-number | 精确参数 | 通过 | 通过 | 通过 | 未变 |
| word-not-ppt | 精确参数 | 通过 | 通过 | 通过 | 未变 |
| cover-number-title | 精确参数 | 通过 | 通过 | 通过 | 未变 |
| missing-image-reference | 缺失与歧义 | 通过 | 通过 | 通过 | 未变 |
| missing-file-read | 缺失与歧义 | 未通过 | 通过 | 通过 | 改善 |
| ambiguous-two-files | 缺失与歧义 | 通过 | 通过 | 通过 | 未变 |
| selected-second-file | 缺失与歧义 | 未通过 | 未通过 | 通过 | 改善 |
| missing-old-file | 缺失与歧义 | 通过 | 未通过 | 未通过 | 退步 |
| data-real-zero | 数据真实性 | 未通过 | 通过 | 通过 | 改善 |
| data-no-imputation | 数据真实性 | 通过 | 通过 | 通过 | 未变 |
| data-example-permitted | 数据真实性 | 通过 | 通过 | 通过 | 未变 |
| data-example-retracted | 数据真实性 | 通过 | 通过 | 通过 | 未变 |
| data-oversize | 数据真实性 | 未通过 | 通过 | 通过 | 改善 |
| research-distinct-topic | 查询与多任务 | 通过 | 通过 | 通过 | 未变 |
| research-no-deliverable | 查询与多任务 | 通过 | 通过 | 通过 | 未变 |
| research-not-time | 查询与多任务 | 通过 | 通过 | 通过 | 未变 |
| research-two-actions | 查询与多任务 | 未通过 | 通过 | 通过 | 改善 |
| research-not-write-memory | 查询与多任务 | 通过 | 通过 | 通过 | 未变 |
| turn-retain-no-images | 多轮状态 | 通过 | 通过 | 通过 | 未变 |
| turn-change-format | 多轮状态 | 通过 | 未通过 | 通过 | 未变 |
| turn-ambiguous-target | 多轮状态 | 服务异常 | 通过 | 通过 | 改善 |
| turn-queued-is-not-done | 多轮状态 | 通过 | 通过 | 通过 | 未变 |
| turn-cancel-do-not-revive | 多轮状态 | 未通过 | 通过 | 通过 | 改善 |
| unsupported-mixed-qzone | 能力与交付边界 | 未通过 | 通过 | 通过 | 改善 |
| unsupported-relay-document | 能力与交付边界 | 通过 | 通过 | 通过 | 未变 |
| cover-recipient-ambiguous | 能力与交付边界 | 通过 | 通过 | 通过 | 未变 |
| cover-next-not-current | 能力与交付边界 | 通过 | 通过 | 通过 | 未变 |
| cover-mixed-document | 能力与交付边界 | 未通过 | 服务异常 | 通过 | 改善 |

## API用量

| 版本 | 调用数 | 输入token | 输出token | 失败请求 |
| --- | --- | --- | --- | --- |
| 改造前 | 118 | 166034 | 87393 | 2 |
| 改造第一轮 | 89 | 165604 | 53557 | 1 |
| 修正后完整复测 | 93 | 170891 | 57720 | 0 |

改造前统计包含超时补跑。用量用于审计，不作为独立性能结论。

## 比较边界

- 这是“意图识别 → 程序校验 → 模拟工具执行”的完整场景通过率，不是单独的意图标签准确率，也没有训练模型权重。
- 三轮使用相同题库哈希、评分函数和deepseek-v4-pro。保留第一次改造结果；最终结果来自修正后的全量40题，不拼接各轮最好成绩。
- 本次根据已知错题修改了架构、状态契约、提示词和输出预算，因此衡量的是组合改造在已知测试集上的效果。尚无独立盲测集，不能据此宣称生产准确率或单独归因于Agent数量。
- 模型仍有波动，每版仅一轮完整采样。改造前包含一次超时补跑且并发设置有变化，后两轮并发2；不将总耗时或用量变化直接当作架构效率结论。
- 服务异常独立列出，不能当作通过。全部场景通过比例保留所有题目为分母，可评分通过率只排除服务异常/未运行。
- 工具全部模拟，没有真实QQ发送、媒体生成或记忆写入；图片和语音用预先解析样例，没有测OCR/ASR或实际交付质量。
- 这次建立了现有助手的单主Agent与受控工作流；未接通企业催办、审批或主动监控，也未验证2000条群消息检索和95%目标。

题库哈希：`43b52fec96c3b75d83b2a617a975c892cb754a4eec1b4bbf7380c7b5491db9b6`；评分版本：`adversarial-v1`。

## 原始证据

- 改造前：[HTML](intent-stress-results.html) / [JSON](intent-stress-results.json)
- 改造第一轮：[HTML](hybrid-after-live.html) / [JSON](hybrid-after-live.json)
- 修正后完整复测：[HTML](hybrid-final-live.html) / [JSON](hybrid-final-live.json)
