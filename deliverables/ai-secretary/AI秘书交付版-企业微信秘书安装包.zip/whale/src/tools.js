import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from './config.js';
import { renderHum } from './music.js';
import { webSearch } from './websearch.js';
import { lookupPart } from './parts.js';
import { listDocs, markSummarized, latestDoc } from './doc-inbox.js';
import { addGlobalFact, isOwner, loadGlobal } from './global.js';
import { addRelay, canRelay, findContact, markDelivered, peekPending } from './relay.js';
import { formatMediaList, searchMedia } from './media-log.js';
import { searchBili, pickVideo, downloadBili, videoFileName } from './bilibili.js';
import { findPython } from './tts.js';
import { logMc } from './mc-log.js';

const STICKER_DIR = path.join(DATA_DIR, 'stickers');
const STICKER_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp']);

/** 分类的中文标签，用来写进工具描述帮模型选。 */
const CATEGORY_HINTS = {
  happy: '开心、庆祝',
  approval: '赞同、答应',
  angry: '生气、不满',
  sad: '难过、委屈',
  confused: '疑惑、没懂',
  surprised: '惊讶、震惊',
  shy: '害羞、尴尬',
  tired: '累、困、摆烂',
  eating: '吃饭、投喂',
  affection: '喜欢、贴贴、安慰',
  greeting: '打招呼、早晚安',
  refusal: '拒绝、不行',
  teasing: '吐槽、调侃、坏笑',
  action: '动作、忙、跑',
  reply: '普通回应',
};

/** 允许模型/用户说中文分类名。 */
const CATEGORY_ALIASES = {
  开心: 'happy', 高兴: 'happy', 庆祝: 'happy', 笑: 'happy',
  赞同: 'approval', 同意: 'approval', 点赞: 'approval',
  生气: 'angry', 愤怒: 'angry', 不满: 'angry',
  难过: 'sad', 伤心: 'sad', 委屈: 'sad', 哭: 'sad',
  疑惑: 'confused', 不懂: 'confused', 问号: 'confused',
  惊讶: 'surprised', 震惊: 'surprised', 吃惊: 'surprised',
  害羞: 'shy', 尴尬: 'shy', 脸红: 'shy',
  累: 'tired', 困: 'tired', 疲惫: 'tired', 摆烂: 'tired', 无语: 'tired',
  吃饭: 'eating', 吃: 'eating', 美食: 'eating', 投喂: 'eating',
  喜欢: 'affection', 贴贴: 'affection', 安慰: 'affection', 爱心: 'affection',
  打招呼: 'greeting', 问候: 'greeting', 早安: 'greeting', 晚安: 'greeting',
  拒绝: 'refusal', 不行: 'refusal', 不要: 'refusal',
  吐槽: 'teasing', 调侃: 'teasing', 坏笑: 'teasing', 玩梗: 'teasing',
  动作: 'action', 忙: 'action', 跑: 'action',
  回应: 'reply', 普通: 'reply',
};

function resolveCategory(input, available) {
  const raw = String(input || '').trim();
  if (!raw) return available.includes('reply') ? 'reply' : available[0];
  const lower = raw.toLowerCase();
  if (available.includes(lower)) return lower;
  if (CATEGORY_ALIASES[raw] && available.includes(CATEGORY_ALIASES[raw])) return CATEGORY_ALIASES[raw];
  const fuzzy = available.find((c) => c.includes(lower) || lower.includes(c));
  return fuzzy || '';
}

/** 扫描 data/stickers/<分类>/ 下的表情包，返回 { 分类: [文件...] }。 */
export function scanStickers() {
  const out = {};
  try {
    for (const entry of fs.readdirSync(STICKER_DIR, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const files = fs
        .readdirSync(path.join(STICKER_DIR, entry.name))
        .filter((f) => STICKER_EXT.has(path.extname(f).toLowerCase()))
        .map((f) => path.join(STICKER_DIR, entry.name, f));
      if (files.length) out[entry.name] = files;
    }
  } catch {
    /* 没有表情包目录就跳过 */
  }
  return out;
}

const SPECS = {
  draw_image: {
    type: 'function',
    function: {
      name: 'draw_image',
      description:
        '画一张图并发给对方。当对方要图、要你画东西、想看照片/插画、或者你想用画面表达时调用。' +
        'prompt 尽量用英文短语写画面本身（主体、动作、场景、光线、画风），英文出图效果明显更好；写不出英文就写中文，会自动翻译。' +
        '对方说画鲸鱼就画鲸鱼、画猫就画猫，除非对方明确要画你，否则不要把自己写进去。',
      parameters: {
        type: 'object',
        properties: {
          prompt: { type: 'string', description: '画面描述（优先英文），尽量具体：主体、动作、场景、光线、画风' },
          size: {
            type: 'string',
            description: '尺寸，可选：square / portrait / landscape / wide / tall，或 1024x1024 这样的格式',
          },
        },
        required: ['prompt'],
      },
    },
  },
  get_time: {
    type: 'function',
    function: {
      name: 'get_time',
      description: '获取当前本地日期、时间和星期几。回答“现在几点/今天几号/星期几”前先调用。',
      parameters: { type: 'object', properties: {} },
    },
  },
  remember: {
    type: 'function',
    function: {
      name: 'remember',
      description:
        '把对方的重要信息长期记住，比如名字、生日、正在忙的事、喜好、约定。只记真正值得记的，不要记闲聊。',
      parameters: {
        type: 'object',
        properties: { text: { type: 'string', description: '一条简短的事实，不超过 50 字' } },
        required: ['text'],
      },
    },
  },
  send_voice: {
    type: 'function',
    function: {
      name: 'send_voice',
      description:
        '用语音（晓伊的声音）把一句话说给对方听。对方让你「发语音」「说句话」「念一下」「用声音说」时用；一次不超过 60 字，短句口语，不要长篇大论。',
      parameters: {
        type: 'object',
        properties: { text: { type: 'string', description: '要说的话，口语短句，不超过 60 字' } },
        required: ['text'],
      },
    },
  },
  sing: {
    type: 'function',
    function: {
      name: 'sing',
      description:
        '哼一段旋律当作唱歌（只有哼唱旋律，不会真的唱出歌词）。对方说「哼一段」「来一句」时用。' +
        '用完在回复里可以顺口写一两句歌词，但别假装自己唱出了人声。',
      parameters: {
        type: 'object',
        properties: { lyrics: { type: 'string', description: '可选：想配的歌词，没给就自己编一两句' } },
      },
    },
  },
  sing_song: {
    type: 'function',
    function: {
      name: 'sing_song',
      description:
        '生成一首完整的歌（有真人声演唱 + 伴奏，1~2 分钟出结果，会以文件发出去）。' +
        '对方说「唱一首完整的歌」「写首歌」「唱给我听」且想要成品时用这个；只想听哼两句就用 sing。' +
        '歌词你可以自己写，用 [verse] [chorus] 分段；style 写风格/心情/乐器。',
      parameters: {
        type: 'object',
        properties: {
          lyrics: { type: 'string', description: '歌词，带 [verse]/[chorus] 分段，中文即可' },
          style: { type: 'string', description: '风格描述，例如 gentle seaside folk, soft female vocal, acoustic guitar' },
          title: { type: 'string', description: '歌名，可选' },
          seconds: { type: 'number', description: '时长秒数，默认 30，最长 60' },
        },
        required: ['lyrics'],
      },
    },
  },
  post_qzone: {
    type: 'function',
    function: {
      name: 'post_qzone',
      description:
        '在 QQ 空间发一条说说（会自动配一张图）。对方说「发条说说」「发个动态」「发空间」「更新一下空间」时用。',
      parameters: {
        type: 'object',
        properties: {
          content: { type: 'string', description: '说说正文，1~2 句口语，符合你的人设' },
          image: { type: 'string', description: '可选：配图的英文画面描述；不填就按正文自动配图' },
          withImage: { type: 'boolean', description: '是否配图，默认 true' },
        },
        required: ['content'],
      },
    },
  },
  make_ppt: {
    type: 'function',
    function: {
      name: 'make_ppt',
      description:
        '做一份 PPT（.pptx 文件）。对方要「做个PPT」「汇报材料」「演示文稿」「课件」时用。会自己写大纲、排版、配图。',
      parameters: {
        type: 'object',
        properties: {
          topic: { type: 'string', description: '主题，尽量具体，比如“朱元璋生平：从乞丐到开国皇帝”' },
          pages: { type: 'number', description: '总页数（含封面和结束页），默认 8，范围 3~24' },
          theme: { type: 'string', enum: ['history', 'business', 'fresh'], description: '配色主题，历史/商务/清新' },
        },
        required: ['topic'],
      },
    },
  },
  make_docx: {
    type: 'function',
    function: {
      name: 'make_docx',
      description: '写一份 Word 文档（.docx）。对方要「写个报告」「方案」「总结」「Word」时用。',
      parameters: {
        type: 'object',
        properties: {
          topic: { type: 'string', description: '主题' },
          sections: { type: 'number', description: '小节数量，默认 5，范围 3~10' },
        },
        required: ['topic'],
      },
    },
  },
  search_history: {
    type: 'function',
    function: {
      name: 'search_history',
      description:
        '在你们过去的聊天记录里搜索关键词。对方问「我之前说过什么」「你还记得吗」「上次那个…」时，先用它查，再回答，不要瞎猜。',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: '要搜索的关键词，可以多给几个，用空格分开' },
          limit: { type: 'number', description: '返回条数，默认 8，最多 12' },
        },
        required: ['query'],
      },
    },
  },
  search_web: {
    type: 'function',
    function: {
      name: 'search_web',
      description:
        '联网搜索。遇到你不认识的网络热梗、新词、新闻、时效信息，或对方问「你知道吗/帮我查一下」时用它，不要硬猜。',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: '搜索关键词，尽量具体，比如“嘉豪 是什么梗”' },
        },
        required: ['query'],
      },
    },
  },
  make_excel: {
    type: 'function',
    function: {
      name: 'make_excel',
      description:
        '生成 Excel 表格（.xlsx）。忠实保留用户给定的数据与计算要求，不擅自补商品、费用、税费或示例数据；只有明确要求示例时才编造示例。',
      parameters: {
        type: 'object',
        properties: {
          topic: { type: 'string', description: '表格主题，尽量具体，比如“奶茶店一周销售流水”' },
          rows: { type: 'number', description: '参考行数，默认 10，范围 1~200；已有数据不凑行数' },
          columns: { type: 'number', description: '参考列数，默认 5，范围 1~20' },
        },
        required: ['topic'],
      },
    },
  },
  send_document: {
    type: 'function',
    function: {
      name: 'send_document',
      description:
        '把资料库里已有的 Word / PPT / Excel / PDF 发给对方（按文件名关键词查找）。' +
        '对方说“把之前那个文档发我”“把 XX 的 PPT 发过来”时用。只有主人能用。',
      parameters: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: '文件名关键词，比如“朱棣”“周报”“小鲸鱼”' },
        },
        required: ['keyword'],
      },
    },
  },
  forward_file: {
    type: 'function',
    function: {
      name: 'forward_file',
      description:
        '把刚收到的文件（Word/PPT/Excel/PDF）原样转发给白名单里的某个好友。' +
        '对方说“把这个发给 XX”“转给 小明”“传给老王”“发给他”时用。只有主人能用。',
      parameters: {
        type: 'object',
        properties: {
          to: { type: 'string', description: '好友昵称或 QQ 号' },
          file: { type: 'string', description: '文件名关键词；留空表示最近收到的那份' },
        },
        required: ['to'],
      },
    },
  },
  inbox_list: {
    type: 'function',
    function: {
      name: 'inbox_list',
      description: '查看员工最近私发来的、还没汇总的 Word/PPT/Excel 文档列表。只有主人能用。',
      parameters: {
        type: 'object',
        properties: {
          hours: { type: 'number', description: '看最近多少小时，默认 48' },
        },
      },
    },
  },
  summarize_inbox: {
    type: 'function',
    function: {
      name: 'summarize_inbox',
      description:
        '把员工私发来的 Word/PPT/Excel 汇总成一份 Word（每份文档 3~5 条要点 + 总体概览），' +
        '然后发给主人。老板说“把大家发的文档汇总一下”“整理成一份给我”时用。只有主人能用。',
      parameters: {
        type: 'object',
        properties: {
          hours: { type: 'number', description: '汇总最近多少小时，默认 48' },
          title: { type: 'string', description: '汇总文档标题，可留空' },
        },
      },
    },
  },
  lookup_part: {
    type: 'function',
    function: {
      name: 'lookup_part',
      description:
        '查汽修配件分类库（24 类）：按中文名、俗称、英文名或外观特征检索，返回 part_id、别名、外观线索、易混项和追问注意。对方问“这是什么配件/这个怎么配/什么型号”且涉及配件时用。',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: '配件名称或俗称，比如“刹车片”“空气滤芯”“火花塞”' },
        },
        required: ['query'],
      },
    },
  },
  remember_global: {
    type: 'function',
    function: {
      name: 'remember_global',
      description:
        '把关于主人的公开信息记到全局记忆（所有和你聊天的人都能看到，比如主人的名字、喜好、称呼）。只有主人本人能用。',
      parameters: {
        type: 'object',
        properties: {
          text: { type: 'string', description: '一条公开事实，比如“主人喜欢打篮球”' },
        },
        required: ['text'],
      },
    },
  },
  relay_message: {
    type: 'function',
    function: {
      name: 'relay_message',
      description:
        '帮对方给主人带一句话（只有主人白名单里的好友能用）。对方说“帮我告诉主人…”“帮我转告你主人…”时用。',
      parameters: {
        type: 'object',
        properties: {
          text: { type: 'string', description: '要转告的内容，尽量保留原话，不超过 200 字' },
        },
        required: ['text'],
      },
    },
  },
  relay_list: {
    type: 'function',
    function: {
      name: 'relay_list',
      description: '查看还有哪些没转告给主人的话（只有主人能用）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  relay_to_friend: {
    type: 'function',
    function: {
      name: 'relay_to_friend',
      description:
        '主人让给某个好友带话时用（只有主人能用）。主人说“帮我告诉 小明……”“给某某发一句……”时调用，会立刻发出去。',
      parameters: {
        type: 'object',
        properties: {
          to: { type: 'string', description: '对方的昵称或 QQ 号' },
          text: { type: 'string', description: '要发的内容，保留原话，不超过 200 字' },
        },
        required: ['to', 'text'],
      },
    },
  },
  find_media: {
    type: 'function',
    function: {
      name: 'find_media',
      description:
        '在长期文件记忆里查历史收发的文件、图片、音频（含文件名和内容摘要）。对方问“我之前发你的那个表格”“上周那份报价单”“你发给我的那首歌”时用。',
      parameters: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: '关键词，比如“报价单”“docx”“烟火”“PPT”；空字符串表示最近的文件' },
        },
      },
    },
  },
  mc_connect: {
    type: 'function',
    function: {
      name: 'mc_connect',
      description: '让机器人进入 Minecraft 服务器（只有主人能用）。对方说“连 127.0.0.1:25565”“进服陪我玩”时用。',
      parameters: {
        type: 'object',
        properties: {
          host: { type: 'string', description: '服务器地址，默认 127.0.0.1' },
          port: { type: 'string', description: '端口，默认 25565' },
        },
      },
    },
  },
  mc_status: {
    type: 'function',
    function: {
      name: 'mc_status',
      description: '查看机器人在 Minecraft 里的状态：坐标、血量、饥饿、维度、在线玩家、手持物。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_move: {
    type: 'function',
    function: {
      name: 'mc_move',
      description: '让机器人走到指定坐标（只有主人能用）。一次最多走 20 秒，没到会报超时。',
      parameters: {
        type: 'object',
        properties: {
          x: { type: 'string' }, y: { type: 'string' }, z: { type: 'string' },
        },
        required: ['x', 'y', 'z'],
      },
    },
  },
  mc_dig: {
    type: 'function',
    function: {
      name: 'mc_dig',
      description: '让机器人挖最近的某种方块（只有主人能用）。方块名用英文 id，例如 oak_log、iron_ore、stone。',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: '方块英文名' },
          count: { type: 'string', description: '挖几个，默认 1，最多 12' },
        },
        required: ['name'],
      },
    },
  },
  mc_say: {
    type: 'function',
    function: {
      name: 'mc_say',
      description: '让机器人在 Minecraft 公屏说一句话（所有玩家可见）。',
      parameters: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
    },
  },
  mc_inventory: {
    type: 'function',
    function: {
      name: 'mc_inventory',
      description: '查看机器人在 Minecraft 里的背包和手持物。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_follow: {
    type: 'function',
    function: {
      name: 'mc_follow',
      description: '让机器人在 Minecraft 里跟着某个玩家走（只有主人能用）。',
      parameters: { type: 'object', properties: { name: { type: 'string', description: '玩家名' } }, required: ['name'] },
    },
  },
  mc_stop: {
    type: 'function',
    function: {
      name: 'mc_stop',
      description: '让机器人停下当前动作（停止跟随、停止寻路）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_eat: {
    type: 'function',
    function: {
      name: 'mc_eat',
      description: '让机器人吃东西回饥饿值（背包里有食物才行）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_place: {
    type: 'function',
    function: {
      name: 'mc_place',
      description: '让机器人在指定坐标放一个方块（需要背包里有这个方块）。',
      parameters: {
        type: 'object',
        properties: {
          x: { type: 'string' }, y: { type: 'string' }, z: { type: 'string' },
          name: { type: 'string', description: '方块名，比如 oak_planks、dirt、cobblestone' },
        },
        required: ['x', 'y', 'z', 'name'],
      },
    },
  },
  mc_craft: {
    type: 'function',
    function: {
      name: 'mc_craft',
      description: '让机器人在 Minecraft 里合成物品（只有主人能用）。会尽量自动补木板、木棍等中间材料。',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: '物品名，如 oak_planks、stick、crafting_table、wooden_pickaxe、chest' },
          count: { type: 'string', description: '数量，默认 1' },
        },
        required: ['name'],
      },
    },
  },
  mc_chest: {
    type: 'function',
    function: {
      name: 'mc_chest',
      description: '让机器人操作附近的箱子：list 看内容、put 存东西、take 取东西（只有主人能用）。',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', description: 'list / put / take' },
          name: { type: 'string', description: '物品名（put/take 需要）' },
          count: { type: 'string', description: '数量' },
        },
        required: ['action'],
      },
    },
  },
  mc_attack: {
    type: 'function',
    function: {
      name: 'mc_attack',
      description: '让机器人打附近 16 格内的怪（只有主人能用）。不给名字就打最近的敌对生物。',
      parameters: {
        type: 'object',
        properties: { name: { type: 'string', description: '怪的名字，比如 zombie，可留空' } },
      },
    },
  },
  mc_sleep: {
    type: 'function',
    function: {
      name: 'mc_sleep',
      description: '让机器人走到附近床上睡觉（只有主人能用，夜晚或雷雨才有效）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_task: {
    type: 'function',
    function: {
      name: 'mc_task',
      description: '给机器人派长任务：收集 N 个方块，挖够自动回来。也可查进度、取消（只有主人能用）。',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', description: 'start / status / cancel' },
          block: { type: 'string', description: '方块英文名（start 且不填 target 时用）' },
          target: { type: 'string', description: '按目标自动规划：iron / stone / wood / coal' },
          count: { type: 'string', description: '数量' },
        },
        required: ['action'],
      },
    },
  },
  mc_build: {
    type: 'function',
    function: {
      name: 'mc_build',
      description: '用背包里的方块在指定坐标搭一个实心长方体（最多 64 格，只有主人能用）。',
      parameters: {
        type: 'object',
        properties: {
          x: { type: 'string' }, y: { type: 'string' }, z: { type: 'string' },
          width: { type: 'string' }, height: { type: 'string' }, depth: { type: 'string' },
          block: { type: 'string', description: '方块名，如 cobblestone、oak_planks' },
        },
        required: ['x', 'y', 'z', 'block'],
      },
    },
  },
  mc_farm: {
    type: 'function',
    function: {
      name: 'mc_farm',
      description: '让机器人收割附近成熟的作物（小麦/胡萝卜/土豆/甜菜，只有主人能用）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  mc_disconnect: {
    type: 'function',
    function: {
      name: 'mc_disconnect',
      description: '让机器人从 Minecraft 下线（只有主人能用）。',
      parameters: { type: 'object', properties: {} },
    },
  },
  fetch_video: {
    type: 'function',
    function: {
      name: 'fetch_video',
      description:
        '去 B 站找一个短视频并发给对方（约 5 分钟以内、30MB 以内）。对方说“给我找个 xx 视频”“发个搞笑视频”“找个猫猫视频”时用。',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: '视频关键词，比如“猫猫”“搞笑翻车”“周杰伦演唱会”' },
        },
        required: ['query'],
      },
    },
  },
};

/**
 * 出图质检：让视觉模型看有没有多余物体/肢体错误/乱码文字。
 * 返回 { bad, issue }，失败就当没问题。
 */
async function checkImageQuality(llm, file, logger, model) {
  if (!llm?.chat) return null;
  try {
    const buf = fs.readFileSync(file);
    const ext = path.extname(file).toLowerCase() === '.png' ? 'png' : 'jpeg';
    const dataUrl = `data:image/${ext};base64,${buf.toString('base64')}`;
    const res = await llm.chat({
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text:
                '检查这张图有没有明显错误：1) 重复或多出来的物体（比如多出来一个篮球/一只手/一只鞋）2) 肢体、手指错乱 3) 衣服或背景上的乱码文字 4) 身体部件是否断开或悬空（比如尾巴、翅膀与身体分离，或单独漂在旁边）。' +
                '只输出 JSON：{"bad": true 或 false, "issue": "简短说明哪里错了"}。没问题就 bad=false。',
            },
            { type: 'image_url', image_url: { url: dataUrl } },
          ],
        },
      ],
      model: model || 'deepseek-flash',
      maxTokens: 500,
      temperature: 0,
    });
    const text = String(res.content || '');
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return null;
    const parsed = JSON.parse(m[0]);
    return { bad: Boolean(parsed.bad), issue: String(parsed.issue || '').slice(0, 80) };
  } catch (err) {
    logger?.warn?.(`出图质检失败：${err.message}`);
    return null;
  }
}

const QUALITY_SUFFIX =
  '。画面里只出现一个主体和必要道具，不要重复物体，不要多出来的球或手，不要多余的鞋或脚，肢体比例正常；' +
  '如果是人外或半人外角色（尾巴、翅膀、耳朵），这些部件必须与身体自然连接，不能悬空、不能断开、不能单独漂在旁边；' +
  '构图完整，不要文字、字母、数字、logo、水印';

/**
 * 组装可用工具。
 * ctx: { chatKey, images: [], voices: [], memory }
 */
export function createTools({ cfg, llm, imageGen, tts, songGen, qzone, office, minecraft, onebot, relayNotify, friendNotify, jobTracker, logger, allowedTools }) {
  if (allowedTools !== undefined && !Array.isArray(allowedTools)) {
    throw new TypeError('allowedTools must be an array when provided');
  }
  const allowed = allowedTools === undefined ? null : new Set(allowedTools);
  const stickers = scanStickers();
  const stickerCats = Object.keys(stickers);
  const specs = [SPECS.draw_image, SPECS.get_time, SPECS.remember, SPECS.sing, SPECS.search_history, SPECS.search_web];
  if (cfg.tts?.enabled && tts) specs.push(SPECS.send_voice);
  if (songGen?.enabled) specs.push(SPECS.sing_song);
  if (qzone?.enabled) specs.push(SPECS.post_qzone);
  if (office) specs.push(SPECS.make_ppt, SPECS.make_docx, SPECS.make_excel);
  specs.push(
    SPECS.lookup_part,
    SPECS.send_document,
    SPECS.forward_file,
    SPECS.inbox_list,
    SPECS.summarize_inbox,
    SPECS.remember_global,
    SPECS.relay_message,
    SPECS.relay_list,
    SPECS.relay_to_friend,
    SPECS.find_media,
    SPECS.fetch_video,
    SPECS.mc_connect,
    SPECS.mc_status,
    SPECS.mc_move,
    SPECS.mc_dig,
    SPECS.mc_say,
    SPECS.mc_inventory,
    SPECS.mc_follow,
    SPECS.mc_stop,
    SPECS.mc_eat,
    SPECS.mc_place,
    SPECS.mc_craft,
    SPECS.mc_chest,
    SPECS.mc_attack,
    SPECS.mc_sleep,
    SPECS.mc_task,
    SPECS.mc_build,
    SPECS.mc_farm,
    SPECS.mc_disconnect,
  );
  if (stickerCats.length) {
    const labels = stickerCats.map((c) => `${c}（${CATEGORY_HINTS[c] || c}）`).join('、');
    specs.push({
      type: 'function',
      function: {
        name: 'send_sticker',
        description: `发一张表情包。可用分类：${labels}。挑最贴合当下情绪的一类，一张就够，别连着发；对方说「来个表情/发个表情包/斗图」时**必须调用本工具**发一张，不能只回文字。`,
        parameters: {
          type: 'object',
          properties: {
            category: { type: 'string', enum: stickerCats, description: '表情分类' },
          },
          required: ['category'],
        },
      },
    });
  }

  const visibleSpecs = allowed ? specs.filter((spec) => allowed.has(spec.function.name)) : specs;
  const runnableNames = new Set(visibleSpecs.map((spec) => spec.function.name));
  const cooldowns = new Map();
  const recentStickers = new Map();

  async function run(name, args, ctx) {
    // Filtering schemas alone does not prevent a model from requesting another tool.
    if (allowed && !runnableNames.has(name)) return `当前渠道不可用工具：${name}`;
    const t0 = Date.now();
    try {
      switch (name) {
        case 'draw_image': {
          if (!cfg.image.enabled) return '出图功能现在是关的，画不了。';
          const key = ctx.chatKey;
          const cooldown = Math.max(cfg.image.cooldownMs ?? 0, cfg.image.provider === 'pollinations' ? 45000 : 0);
          const last = cooldowns.get(key) ?? 0;
          if (Date.now() - last < cooldown) {
            return `刚画过一张，等一下再画（还要 ${Math.ceil((cooldown - (Date.now() - last)) / 1000)} 秒）。`;
          }
          const jid = jobTracker?.begin ? jobTracker.begin('draw', `画图：${String(args.prompt || '').slice(0, 24)}`) : '';
          try {
            const prompt = await toImagePrompt(llm, args.prompt, logger, cfg.llm?.helperModel);
            const finalPrompt = `${prompt}${QUALITY_SUFFIX}`;
            logger.info(`出图提示词：${finalPrompt.slice(0, 160)}`);
            let img = await imageGen.generate({ prompt: finalPrompt, size: args.size });
            // 质检：有多余物体/乱码文字就补画一张
            const qa = await checkImageQuality(llm, img.file, logger, cfg.llm?.visionModel);
            if (qa?.bad) {
              logger.warn(`出图质检不合格：${qa.issue}`);
              const retryPrompt = `${prompt}。严格避免以下问题：${qa.issue || '多余物体、肢体错误、乱码文字'}${QUALITY_SUFFIX}`;
              const second = await imageGen.generate({ prompt: retryPrompt, size: args.size }).catch((err) => {
                logger.warn(`补画失败，用第一张：${err.message}`);
                return null;
              });
              if (second) img = second;
            }
            cooldowns.set(key, Date.now());
            ctx.images.push(img);
            return `已生成图片：${img.width}x${img.height}。回复里用一句话轻松带过，不要输出路径或链接。`;
          } catch (err) {
            cooldowns.set(key, Date.now());
            if (err.retryAfter) return `这次没画成：${err.message}。跟对方说一声，等会儿再画。`;
            throw err;
          } finally {
            if (jid) jobTracker.end(jid);
          }
        }
        case 'get_time': {
          const now = new Date();
          const week = '日一二三四五六'[now.getDay()];
          return `${now.toLocaleString('zh-CN', { hour12: false })} 星期${week}`;
        }
        case 'send_voice': {
          if (!cfg.tts?.enabled || !tts) return '语音功能现在是关的。';
          const audio = await tts.synthesize(args.text);
          ctx.voices.push(audio);
          return `已用语音发出（音色 ${audio.voice}）。回复里用一句话带过就行，不要重复语音内容。`;
        }
        case 'make_ppt': {
          if (!office) return '文档功能没开。';
          const totalPages = Math.min(Math.max(Math.floor(Number(args.pages) || 8), 3), 24);
          const topic = String(args.topic || '').slice(0, 2000).trim();
          if (!topic) return '主题为空。';
          ctx.documents.push({
            kind: 'ppt',
            topic,
            pages: totalPages - 2,
            totalPages,
            sourceText: [...(ctx.recentUserRequests || []).map(text => `此前用户消息：${text}`),
              `本次用户原始要求：${ctx.requestText || topic}`].join('\n\n').slice(-60000),
            theme: String(args.theme || 'business'),
          });
          return `PPT 任务已安排（共 ${totalPages} 页，含封面和结束页），按原始要求生成并检查后发送文件。`;
        }
        case 'make_docx': {
          if (!office) return '文档功能没开。';
          const sections = Math.min(Math.max(Number(args.sections) || 5, 3), 10);
          const topic = String(args.topic || '').slice(0, 150).trim();
          if (!topic) return '主题为空。';
          ctx.documents.push({ kind: 'docx', topic, sections });
          return `Word 开始写了（${sections} 个小节），一会儿发文件给你。`;
        }
        case 'make_excel': {
          if (!office) return '表格功能没开。';
          const topic = String(args.topic || '').slice(0, 2000).trim();
          if (!topic) return '主题为空。';
          const rows = Math.min(Math.max(Number(args.rows) || 10, 1), 200);
          const columns = Math.min(Math.max(Number(args.columns) || 5, 1), 20);
          const sourceText = [
            ...(ctx.recentUserRequests || []).map(text => `此前用户消息：${text}`),
            `本次用户原始要求：${ctx.requestText || topic}`,
          ].join('\n\n').slice(-60000);
          ctx.documents.push({ kind: 'excel', topic, sourceText, rows, columns });
          return '表格任务已安排，将按原始数据和要求生成后发送文件。';
        }
        case 'forward_file': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能让我转发文件。';
          if (!onebot) return '发送通道没接上。';
          const to = String(args.to || '').trim();
          if (!to) return '要转给谁？给我昵称或 QQ 号。';

          const contact = findContact(to);
          if (!contact) return `没找到「${to}」。让他先给我发条消息，或者直接把 QQ 号给我。`;

          const allow = (cfg.access?.privateAllow || []).map(String).filter(Boolean);
          if (allow.length && !allow.includes(String(contact.uin))) {
            return `「${contact.name}」不在白名单里，不能转发。`;
          }

          let doc = latestDoc({ chatKey: ctx.chatKey, keyword: String(args.file || '').trim() });
          if (!doc && args.file) doc = latestDoc({ keyword: String(args.file).trim() });

          // Use only indexed QQ files; never scan shared output folders across channels.
          if (!doc && args.file) {
            doc = searchMedia(String(args.file), '', 5000).filter(item =>
              /^(private|group):\d+$/.test(item.chatKey) && item.kind === 'doc' && item.path && fs.existsSync(item.path)).at(-1);
          }

          if (!doc) return '最近没收到可以转发的文件。先把文件发我，我再转。';

          try {
            const buffer = fs.readFileSync(doc.path);
            await onebot.call(
              'upload_private_file',
              { user_id: Number(contact.uin), file: `base64://${buffer.toString('base64')}`, name: doc.name },
              180000,
            );
            await onebot.sendPrivate(Number(contact.uin), [
              { type: 'text', data: { text: `${ctx.peerName || '有人'} 转发：${doc.name}` } },
            ]);
            return `已把《${doc.name}》转给 ${contact.name}（${contact.uin}）。`;
          } catch (err) {
            return `转发失败：${err.message}`;
          }
        }
        case 'inbox_list': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能看汇总箱。';
          const hours = Math.min(Math.max(Number(args.hours) || 48, 1), 720);
          const docs = listDocs({ hours });
          if (!docs.length) return `最近 ${hours} 小时没有待汇总的文档。`;
          const lines = docs.map((d) => {
            const t = new Date(d.at).toLocaleString('zh-CN', { hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
            return `- ${t}｜${d.senderName || d.uin}｜${d.name}｜${d.chars} 字`;
          });
          return `待汇总文档（${docs.length} 份）：\n${lines.join('\n')}\n回复时说清有几份、谁发的，不要报路径。`;
        }
        case 'summarize_inbox': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能让我汇总文档。';
          if (!office) return '文档功能没开。';
          const hours = Math.min(Math.max(Number(args.hours) || 48, 1), 720);
          const allDocs = listDocs({ hours });
          const docs = allDocs.slice(0, 20);
          if (!docs.length) return `最近 ${hours} 小时没有待汇总的文档。`;

          const formatDoc = async (d) => {
            const text = String(d.text || '').slice(0, 3000);
            if (!text) return [`（这份文档没有抽出文字，文件名：${d.name}）`];
            try {
              const res = await llm.chat({
                model: cfg.office?.model || cfg.llm?.model,
                messages: [
                  {
                    role: 'system',
                    content:
                      '把这份文档压缩成 3~5 条要点，中文，每条一行，直接输出要点，不要开场白。' +
                      '保留数字、结论、负责人、时间；不要编造文档里没有的内容。',
                  },
                  { role: 'user', content: `文件名：${d.name}\n\n${text}` },
                ],
                maxTokens: 500,
                temperature: 0.3,
              });
              const bullets = String(res.content || '')
                .split(/\r?\n/)
                .map((s) => s.replace(/^[-*·\d.、\s]+/, '').trim())
                .filter(Boolean)
                .slice(0, 5);
              return bullets.length ? bullets : [text.slice(0, 80)];
            } catch (err) {
              logger?.warn?.(`汇总 ${d.name} 失败：${err.message}`);
              return [text.slice(0, 80)];
            }
          };

          const sections = [];
          const digest = [];
          for (const d of docs) {
            const bullets = await formatDoc(d);
            digest.push(`${d.senderName || d.uin}《${d.name}》：${bullets.join('；')}`);
            sections.push({
              heading: `${d.name}（${d.senderName || d.uin}）`,
              bullets,
            });
          }

          let intro = `共收到 ${docs.length} 份文档，来自 ${new Set(docs.map((d) => d.uin)).size} 位同事。`;
          try {
            const res = await llm.chat({
              model: cfg.office?.model || cfg.llm?.model,
              messages: [
                { role: 'system', content: '用 3~4 句中文概括这批文档的整体情况：谁交了什么、主要进展、需要老板关注的点。不要编造。' },
                { role: 'user', content: digest.join('\n').slice(0, 4000) },
              ],
              maxTokens: 400,
              temperature: 0.4,
            });
            if (res.content?.trim()) intro = res.content.trim();
          } catch {
            /* 用默认开场 */
          }

          const title = String(args.title || `文档汇总 ${new Date().toLocaleDateString('zh-CN')}`).slice(0, 50);
          const built = await office.makeSummaryDocx({
            title,
            subtitle: `共 ${docs.length} 份 · 生成于 ${new Date().toLocaleString('zh-CN', { hour12: false })}`,
            sections: [{ heading: '总体概览', paragraphs: [intro] }, ...sections],
            theme: cfg.office?.theme || 'business',
          });

          ctx.files.push({ path: built.file, name: built.name, size: fs.statSync(built.file).size,
            onDelivered: () => markSummarized(docs.map(d => d.id)) });
          return `汇总好了：本批${docs.length}份，共${allDocs.length}份待处理，已生成《${built.name}》并加入待发送。成功发送后才标记已汇总。`;
        }
        case 'send_document': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能让我发文件。';
          const kw = String(args.keyword || '').trim().toLowerCase();
          if (!kw) return '要发哪个文件？给我一个文件名关键词。';

          const found = searchMedia(kw, '', 5000).filter(item => /^(private|group):\d+$/.test(item.chatKey)
            && item.kind === 'doc' && item.path && fs.existsSync(item.path)).map(item => ({...item,size:fs.statSync(item.path).size,mtime:item.at}));
          const incoming = listDocs({hours:720,includeSummarized:true}).filter(item => item.name.toLowerCase().includes(kw) && fs.existsSync(item.path));
          for (const doc of incoming) found.push({...doc,size:fs.statSync(doc.path).size,mtime:doc.at});

          if (!found.length) return `资料库里没找到文件名包含「${args.keyword}」的文档。`;
          found.sort((a, b) => b.mtime - a.mtime);
          const pickFile = found[0];
          ctx.files.push({ path: pickFile.path, name: pickFile.name, size: pickFile.size });
          return `已加入待发送：${pickFile.name}（${Math.round(pickFile.size / 1024)}KB）。回复里一句话带过即可，不要报路径。`;
        }
        case 'lookup_part': {
          const q = String(args.query || '').trim();
          if (!q) return '要查什么配件？';
          const rows = lookupPart(q, { limit: 3 });
          if (!rows.length) return `分类库里没有匹配「${q}」的条目。告诉对方需要更多信息（位置/照片/车型），不要编。`;
          const lines = rows.map(
            (r) =>
              `${r.part_id} ${r.name_zh}（${(r.aliases || []).join('/')}）｜外观：${r.visual_cues}｜易混：${(r.confusable_part_ids || []).join(',') || '无'}｜注意：${r.clarification_note}`,
          );
          return `配件分类库匹配结果：\n${lines.join('\n')}\n回复时用口语说类别和需要补充的信息，不要报 part_id，也不要承诺适配或价格。`;
        }
        case 'remember_global': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能改公开记忆。';
          const ok = addGlobalFact(args.text);
          return ok ? `记到公开记忆里了：${args.text}（以后所有人都能看到这条）` : '这条已经记过了。';
        }
        case 'relay_message': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const uin = m?.[1];
          if (!uin) return '群聊里不能传话，私聊找我才行。';
          if (!canRelay(uin, cfg)) return '主人没给我这个权限，不能帮你传话。';
          try {
            const item = addRelay({ uin, name: ctx.peerName || '', text: args.text }, cfg);
            let pushed = false;
            if (relayNotify) {
              try {
                pushed = await relayNotify(item);
              } catch (err) {
                logger?.warn?.(`立即转告失败：${err.message}`);
              }
            }
            if (pushed) {
              markDelivered([item.id]);
              return '已经直接发给主人了。回复里自然说一句“帮你转告了”就行，别报条数。';
            }
            return '好，我记下了，等主人上线就转告他。回复里自然说一句就行，别报条数。';
          } catch (err) {
            return `没传成：${err.message}`;
          }
        }
        case 'relay_list': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能看。';
          const items = peekPending();
          if (!items.length) return '现在没有待转告的话。';
          return `还有 ${items.length} 条没转告：\n${items.map((i) => `- ${i.name || i.from}：${i.text}`).join('\n')}`;
        }
        case 'relay_to_friend': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          if (!isOwner(m?.[1], cfg)) return '只有主人能让我给别人带话。';
          const text = String(args.text || '').trim().slice(0, 200);
          if (!text) return '内容为空。';
          const c = findContact(args.to);
          if (!c) return `没找到「${args.to}」，直接给我 QQ 号，或者让对方先跟我说句话。`;
          if (!friendNotify) return '发送通道没接好。';
          const ownerName = loadGlobal()?.owner?.name || '主人';
          await friendNotify(c.uin, `【传话】${ownerName} 让我跟你说：${text}`);
          return `已经直接发给 ${c.name}（${c.uin}）了。回复里说一句“发过去了”就行。`;
        }
        case 'find_media': {
          const items = searchMedia(args.keyword || '', ctx.chatKey, 10);
          if (!items.length) return '文件记忆里没有匹配的记录。';
          return `文件记忆里找到这些：\n${formatMediaList(items)}\n回复时用口语说，不要报路径。`;
        }
        case 'mc_connect': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我进服务器。';
          if (!minecraft) return 'MC 模块没接上。';
          try {
            const st = await minecraft.connect({ host: args.host, port: args.port });
            logMc({ kind: '进服', detail: `${st.position.x},${st.position.y},${st.position.z}` });
            return `进服了：${st.username} 在 ${st.position.x},${st.position.y},${st.position.z}，血 ${st.health}。回复里说“我进来了”就行。`;
          } catch (err) {
            return `没进去：${String(err.message || '').slice(0, 120)}`;
          }
        }
        case 'mc_status': {
          if (!minecraft?.online) return '现在不在服务器里。';
          const st = minecraft.status();
          return `坐标 ${st.position.x},${st.position.y},${st.position.z}｜血 ${st.health}｜饥饿 ${st.food}｜维度 ${st.dimension}｜在线：${st.players.join('、') || '只有我'}｜手持 ${st.heldItem}`;
        }
        case 'mc_move': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能指挥我走。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const st = await minecraft.moveTo(args.x, args.y, args.z);
            logMc({ kind: '走到', detail: `${st.position.x},${st.position.y},${st.position.z}` });
            return `走到了 ${st.position.x},${st.position.y},${st.position.z}`;
          } catch (err) {
            return `没走到：${String(err.message || '').slice(0, 100)}`;
          }
        }
        case 'mc_dig': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我挖东西。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.dig(args.name, args.count);
            logMc({ kind: '挖方块', detail: `${args.name} x${r.mined}` });
            return `挖到 ${r.mined} 个 ${args.name}${r.remaining ? `，还有 ${r.remaining} 个没挖` : ''}`;
          } catch (err) {
            return `没挖成：${String(err.message || '').slice(0, 100)}`;
          }
        }
        case 'mc_say': {
          if (!minecraft?.online) return '现在不在服务器里。';
          try { minecraft.say(args.text); logMc({ kind: '公屏说话', detail: String(args.text || '').slice(0, 80) }); return '说了。'; } catch (err) { return `没说成：${err.message}`; }
        }
        case 'mc_inventory': {
          if (!minecraft?.online) return '现在不在服务器里。';
          const inv = minecraft.inventory();
          const list = Object.entries(inv.items).slice(0, 12).map(([k, v]) => `${k}x${v}`).join('、');
          return `手持 ${inv.held}｜背包：${list || '空'}`;
        }
        case 'mc_follow': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我跟着走。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.follow(args.name, 3);
            logMc({ kind: '跟随', detail: args.name });
            return `跟着 ${r.following} 走了（保持 ${r.distance} 格）`;
          } catch (err) {
            return `跟不上：${String(err.message || '').slice(0, 100)}`;
          }
        }
        case 'mc_stop': {
          if (!minecraft?.online) return '现在不在服务器里。';
          try { minecraft.stopFollow(); logMc({ kind: '停下' }); return '停下了。'; } catch (err) { return `停不下来：${err.message}`; }
        }
        case 'mc_eat': {
          if (!minecraft?.online) return '现在不在服务器里。';
          const r = await minecraft.eatIfHungry(20);
          if (r.ate) { logMc({ kind: '吃东西' }); return `吃了，饥饿值 ${r.food}`; }
          return r.reason ? `没吃成：${r.reason}` : `还不饿（${r.food}）`;
        }
        case 'mc_place': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我放方块。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.placeAt(args.x, args.y, args.z, args.name);
            logMc({ kind: '放方块', detail: `${args.name} @ ${args.x},${args.y},${args.z}` });
            return '放好了。';
          } catch (err) {
            return `没放成：${String(err.message || '').slice(0, 100)}`;
          }
        }
        case 'mc_craft': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我合成东西。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.craft(args.name, args.count);
            logMc({ kind: '合成', detail: `${r.crafted} x${r.count}` });
            return `做好了 ${r.crafted} x${r.count}`;
          } catch (err) {
            return `没做成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_chest': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我动箱子。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.chest(args.action || 'list', args.name || '', args.count);
            logMc({ kind: '箱子', detail: `${args.action} ${args.name || ''}` });
            if (r.chest) return `箱子里：${(r.chest || []).join('、') || '空'}｜背包：${(r.bag || []).join('、') || '空'}`;
            return `${JSON.stringify(r)}`;
          } catch (err) {
            return `箱子没弄成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_attack': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我打怪。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.attack(args.name || '');
            logMc({ kind: '打怪', detail: `${r.target} 打了${r.hits}下${r.killed ? '，打死了' : ''}` });
            return r.killed ? `打死了 ${r.target}（${r.hits} 下）` : `打了 ${r.target} ${r.hits} 下，它还在`;
          } catch (err) {
            return `没打成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_sleep': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我睡觉。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            await minecraft.sleep();
            logMc({ kind: '睡觉' });
            return '躺下了。';
          } catch (err) {
            return `睡不着：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_task': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能派任务。';
          if (!minecraft?.online) return '现在不在服务器里。';
          const action = String(args.action || 'status');
          try {
            if (action === 'cancel') { minecraft.cancelTask(); logMc({ kind: '取消任务' }); return '任务取消了。'; }
            if (action === 'status') {
              const s = minecraft.taskSummary();
              if (!s.active) return '现在没有在跑的任务。';
              return `${s.block || s.kind} ${s.progress || 0}/${s.target || '?'}｜状态 ${s.status}${s.error ? '｜' + s.error : ''}`;
            }
            if (args.target) {
              const s2 = await minecraft.startGather(args.target, args.count, cfg.mc?.ownerName);
              logMc({ kind: '接任务', detail: `${args.target} x${s2.targetCount}` });
              return `接了：去弄 ${args.target} x${s2.targetCount}，我会先做工具再挖，挖够回来。`;
            }
            if (!args.block) return '要收集什么方块？';
            const s = await minecraft.startCollect(args.block, args.count, cfg.mc?.ownerName);
            logMc({ kind: '接任务', detail: `${args.block} x${s.target}` });
            return `接了：收集 ${args.block} x${s.target}，挖够我就回来。`;
          } catch (err) {
            return `任务没派成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_build': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我盖东西。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.buildBox({ ...args });
            logMc({ kind: '盖方块', detail: `${r.block} x${r.placed}` });
            return `盖好了 ${r.placed} 格（计划 ${r.requested} 格）`;
          } catch (err) {
            return `没盖成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_farm': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我收庄稼。';
          if (!minecraft?.online) return '现在不在服务器里。';
          try {
            const r = await minecraft.harvest();
            logMc({ kind: '收庄稼', detail: `${r.harvested} 株` });
            return `收了 ${r.harvested} 株（附近找到 ${r.found} 处作物）`;
          } catch (err) {
            return `没收成：${String(err.message || '').slice(0, 110)}`;
          }
        }
        case 'mc_disconnect': {
          const m = /^private:(\d+)$/.exec(ctx.chatKey || '');
          const mcOwner = ctx.chatKey === 'mc:server' && String(ctx.peerName || '').toLowerCase() === String(cfg.mc?.ownerName || '').toLowerCase();
          if (!isOwner(m?.[1], cfg) && !mcOwner) return '只有主人能让我下线。';
          await minecraft?.disconnect();
          logMc({ kind: '下线' });
          return '下线了。';
        }
        case 'fetch_video': {
          const q = String(args.query || '').trim();
          if (!q) return '要找什么视频？';
          try {
            const list = await searchBili(q, 10);
            const pick = pickVideo(list, 300);
            if (!pick) return `B站没搜到合适的「${q}」短视频（15 秒~5 分钟）。换个词试试？`;
            const python = findPython(cfg.office?.pythonPath || cfg.tts?.pythonPath || '');
            const file = await downloadBili(pick.bvid, python);
            ctx.videos.push({ file: file.file, name: videoFileName(pick.title), title: pick.title });
            return `找到《${pick.title}》（${pick.durationText}，UP：${pick.author}），视频已经准备好了。回复里说一句“发你啦”就行，别报链接和路径。`;
          } catch (err) {
            return `视频没弄成：${String(err.message || '').slice(0, 120)}。跟对方说一声，换个词再试试。`;
          }
        }
        case 'post_qzone': {
          if (!qzone?.enabled) return '空间功能没开。';
          const content = String(args.content || '').slice(0, 300).trim();
          if (!content) return '说说内容为空，先想一句话。';
          const imagePrompt = String(args.image || '').trim() || content;
          const imagePath = args.withImage === false ? '' : await qzone.makeImage(imagePrompt);
          await qzone.post({ content, imagePath, source: 'tool', chatKey: ctx.chatKey });
          return `说说发出去了${imagePath ? '，配图也一起传了' : '（这次没配图）'}。回复里自然提一句就行，不要报 tid、路径或链接。`;
        }
        case 'sing': {
          const m = cfg.music || {};
          const min = m.minSeconds ?? 18;
          const max = Math.max(min, m.maxSeconds ?? 30);
          const seconds = min + Math.floor(Math.random() * (max - min + 1));
          const hum = renderHum({ seconds, tempo: m.tempo, noise: m.noise });
          ctx.voices.push({ file: hum.file, name: hum.name, hum: true });
          return `已经哼好一段 ${seconds} 秒的旋律并用语音发出。回复里用一句话带过，可以顺口写一两句歌词，但别声称自己唱出了人声。`;
        }
        case 'sing_song': {
          if (!songGen?.enabled) return '完整的歌还没接上，先给你哼一段吧。';
          const seconds = Math.min(Math.max(Number(args.seconds) || cfg.song.defaultSeconds || 30, 10), cfg.song.maxSeconds || 60);
          ctx.songs.push({
            lyrics: String(args.lyrics || '').slice(0, 3000),
            style: String(args.style || '').slice(0, 400),
            title: String(args.title || '').slice(0, 60),
            seconds,
          });
          return `歌已经交给编曲了：大约 ${seconds} 秒，1~2 分钟出结果，好了会直接发文件。回复里跟对方说一声“正在写”就行，别说已经唱完了。`;
        }
        case 'remember': {
          const ok = ctx.memory.addNote(ctx.chatKey, args.text);
          return ok ? `记住了：${args.text}` : '这条已经记过了。';
        }
        case 'search_history': {
          const q = String(args.query || '').trim();
          if (!q) return '要搜什么关键词？';
          const limit = Math.min(Math.max(Number(args.limit) || 8, 1), 12);
          const hits = await ctx.memory.search(ctx.chatKey, q, { limit });
          if (!hits.length) return `没搜到和「${q}」相关的旧对话。回复里可以说记不清了，别编。`;
          const lines = hits.map(
            (h) => `${h.role === 'user' ? '对方' : h.role === 'assistant' ? '你' : '笔记'}：${h.content.slice(0, 80)}`,
          );
          return `搜到这些旧记录（按相关度）：\n${lines.join('\n')}`;
        }
        case 'search_web': {
          const q = String(args.query || '').trim();
          if (!q) return '要搜什么？';
          const items = await webSearch(q, { limit: 5 });
          if (!items.length) return `没搜到「${q}」的结果。回复里说没查到，别编。`;
          const lines = items.map(
            (i, idx) => `${idx + 1}. ${i.title}${i.snippet ? `：${i.snippet.slice(0, 90)}` : ''}`,
          );
          return `搜索结果（${items.length} 条）：\n${lines.join('\n')}\n用自然口语总结给对方面，不要报链接。`;
        }
        case 'send_sticker': {
          const cat = resolveCategory(args.category, stickerCats);
          const list = cat ? stickers[cat] : null;
          if (!list?.length) {
            return `没有这个分类的表情包，可用：${stickerCats.map((c) => `${c}(${CATEGORY_HINTS[c] || c})`).join('、')}`;
          }
          const recent = recentStickers.get(ctx.chatKey) ?? [];
          const pool = list.filter((f) => !recent.includes(f));
          const from = pool.length ? pool : list;
          const file = from[Math.floor(Math.random() * from.length)];
          recent.push(file);
          while (recent.length > 8) recent.shift();
          recentStickers.set(ctx.chatKey, recent);
          ctx.images.push({ file, name: path.basename(file), sticker: true });
          return `已发送一张「${cat}」表情包。回复里一句话带过就行。`;
        }
        default:
          return `未知工具：${name}`;
      }
    } catch (err) {
      logger.warn(`工具 ${name} 失败：${err.message}`);
      return `工具执行失败：${err.message}`;
    } finally {
      logger.info(`工具 ${name} 用时 ${Date.now() - t0}ms`);
    }
  }

  return {
    specs: visibleSpecs,
    // Keep everyday and follow-up capabilities available. Only hide the large MC family
    // when neither the current request nor recent context concerns the game.
    specsFor(ctx = {}) {
      const text = [ctx.text, ctx.requestText, ...(ctx.recentUserRequests || [])].filter(Boolean).join('\n');
      const mcHint = minecraft?.online || /(我的世界|minecraft|\bmc\b|游戏|服务器|挖|合成|怪|箱子|木头|跟着|方块)/i.test(text);
      return visibleSpecs.filter(s => mcHint || !s.function.name.startsWith('mc_'));
    },
    run,
    stickerCats: allowed && !runnableNames.has('send_sticker') ? [] : stickerCats,
    imageEnabled: Boolean(cfg.image.enabled) && (!allowed || runnableNames.has('draw_image')),
    ttsEnabled: Boolean(cfg.tts?.enabled) && (!allowed || runnableNames.has('send_voice')),
  };
}

/** 中文提示词先翻成英文 tag，出图质量会好很多。用便宜的 flash 模型，不占主模型额度。 */
async function toImagePrompt(llm, prompt, logger, helperModel) {
  const text = String(prompt || '').trim();
  if (!text) throw new Error('空提示词');
  const hasCJK = /[\u4e00-\u9fff]/.test(text);
  let english = text;
  if (hasCJK) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await llm.chat({
          messages: [
            {
              role: 'system',
              content:
                '把用户的中文画面描述翻译成英文 AI 绘画提示词：逗号分隔的短标签，按「主体（保留原意，鲸鱼就是鲸鱼，不要翻成人）、外观、动作、场景、光线、构图、画风」排列。' +
                '画风默认 anime illustration / illustration，除非用户明确要照片或写实。只输出英文提示词本身，不要引号、不要解释。',
            },
            { role: 'user', content: text },
          ],
          model: helperModel || llm.cfg.visionModel,
          maxTokens: 400,
          temperature: 0.3,
        });
        const out = (res.content || '').trim().replace(/^["'`]+|["'`]+$/g, '');
        if (out.length >= 8 && !/[\u4e00-\u9fff]/.test(out)) {
          english = out;
          break;
        }
        logger.warn(`提示词翻译结果不合格（第 ${attempt + 1} 次）：${out.slice(0, 40) || '空'}`);
      } catch (err) {
        logger.warn(`提示词翻译失败（第 ${attempt + 1} 次）：${err.message}`);
      }
    }
  }
  const suffix = hasCJK && /[\u4e00-\u9fff]/.test(english) ? 'anime illustration, best quality, detailed' : 'best quality, detailed, soft lighting';
  return `${english}, ${suffix}`;
}
