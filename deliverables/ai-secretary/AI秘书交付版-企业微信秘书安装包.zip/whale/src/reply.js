import fs from 'node:fs';
import path from 'node:path';
import { seg } from './onebot.js';
import { sleep } from './llm.js';

const rand = ([min, max]) => min + Math.random() * (max - min);

/** 把一条回复拆成“人味”：先等一下，再一条条发，中间有停顿。 */
export class ReplySender {
  constructor({ onebot, cfg, logger }) {
    this.onebot = onebot;
    this.cfg = cfg;
    this.logger = logger;
    this.chains = new Map();
  }

  updateConfig(cfg) {
    this.cfg = cfg;
  }

  send(chat, result, { quoteId } = {}) {
    const key = chat.key;
    const prev = this.chains.get(key) ?? Promise.resolve();
    const next = prev
      .catch(() => {})
      .then(() => this.#sendNow(chat, result, quoteId))
      .finally(() => {
        if (this.chains.get(key) === next) this.chains.delete(key);
      });
    this.chains.set(key, next);
    return next;
  }

  async #sendNow(chat, result, quoteId) {
    const { bubbles = [], images = [], voices = [], files = [] } = result;
    if (!bubbles.length && !images.length && !voices.length && !files.length) return;

    await sleep(rand(this.cfg.firstDelayMs));

    for (let i = 0; i < bubbles.length; i++) {
      const text = bubbles[i];
      const segments = [];
      if (i === 0 && quoteId) segments.push(seg.reply(quoteId));
      segments.push(seg.text(text));
      await this.#call(chat, segments);
      if (i < bubbles.length - 1) {
        await sleep(rand(this.cfg.splitDelayMs) + Math.min(1200, text.length * 18));
      }
    }

    for (const voice of voices) {
      try {
        const buffer = fs.readFileSync(voice.file);
        await this.#call(chat, [{ type: 'record', data: { file: `base64://${buffer.toString('base64')}` } }]);
        await sleep(rand([400, 900]));
      } catch (err) {
        this.logger.warn(`发送语音失败：${err.message}`);
      }
    }

    for (const img of images) {
      try {
        const buffer = fs.readFileSync(img.file);
        const segments = [{ type: 'image', data: { file: `base64://${buffer.toString('base64')}` } }];
        await this.#call(chat, segments);
        await sleep(rand([300, 900]));
      } catch (err) {
        this.logger.warn(`发送图片失败：${err.message}`);
      }
    }

    for (const f of files) {
      try {
        await this.sendFile(chat, f.path, f.name, '');
        await f.onDelivered?.();
        await sleep(rand([500, 1100]));
      } catch (err) {
        this.logger.warn(`发送文件失败：${err.message}`);
        throw err;
      }
    }
  }

  /**
   * 发音频：按配置决定用「语音条」还是「文件」。
   * mode: true 强制语音 / false 强制文件 / 'auto' 60 秒内走语音
   */
  async sendAudio(chat, filePath, name, text, mode = 'auto', duration = 0) {
    const seconds = duration || estimateDuration(filePath);
    const canVoice = seconds > 0 && seconds <= 55;
    const wantVoice = mode === true || (mode === 'auto' && canVoice);

    if (wantVoice && canVoice) {
      const buffer = fs.readFileSync(filePath);
      if (text) await this.#call(chat, [seg.text(text)]);
      await this.#call(chat, [{ type: 'record', data: { file: `base64://${buffer.toString('base64')}` } }]);
      this.logger.info(`已用语音条发送（约 ${Math.round(seconds)} 秒）`);
      return;
    }
    if (wantVoice && !canVoice) {
      this.logger.warn(`音频约 ${Math.round(seconds)} 秒，超过语音条上限，改发文件`);
    }
    return this.sendFile(chat, filePath, name, text);
  }

  /** 发视频消息（QQ 里能直接播放），失败退回文件。 */
  async sendVideo(chat, filePath, name, text) {
    const buffer = fs.readFileSync(filePath);
    if (text) await this.#call(chat, [seg.text(text)]);
    try {
      await this.#call(chat, [{ type: 'video', data: { file: `base64://${buffer.toString('base64')}` } }], 180000);
      return;
    } catch (err) {
      this.logger.warn(`视频消息发送失败，改用文件：${err.message}`);
      return this.sendFile(chat, filePath, name, '');
    }
  }

  /** 发文件（歌曲等大文件），QQ 里会显示成文件消息。 */
  async sendFile(chat, filePath, name, text) {
    const buffer = fs.readFileSync(filePath);
    const fileName = name || path.basename(filePath);
    if (text) await this.#call(chat, [seg.text(text)]);
    const payload = { file: `base64://${buffer.toString('base64')}`, name: fileName };
    const action = chat.type === 'group' ? 'upload_group_file' : 'upload_private_file';
    const params = chat.type === 'group' ? { group_id: chat.groupId, ...payload } : { user_id: chat.userId, ...payload };

    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await this.onebot.call(action, params, 120000);
      } catch (err) {
        this.logger.warn(`发送文件失败（第 ${attempt + 1} 次）：${err.message}`);
        if (attempt === 1) {
          // 文件发不出去就退回语音条（QQ 语音上限约 60 秒）
          try {
            await this.#call(chat, [{ type: 'record', data: { file: payload.file } }]);
            this.logger.info('文件发送失败，已改用语音条发送');
            return;
          } catch (voiceErr) {
            this.logger.warn(`语音条也失败了：${voiceErr.message}`);
            throw err;
          }
        }
        await sleep(1500);
      }
    }
  }

  #call(chat, segments, timeout = 20000) {
    if (chat.type === 'group') return this.onebot.sendGroup(chat.groupId, segments, timeout);
    return this.onebot.sendPrivate(chat.userId, segments, timeout);
  }
}

/** 没有 ffprobe，就按常见码率估算时长（够判断 60 秒上限）。 */
function estimateDuration(filePath) {
  try {
    const size = fs.statSync(filePath).size;
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.mp3') return (size * 8) / 128000; // 128kbps
    if (ext === '.wav') return size / (16000 * 2); // 16k 单声道 16bit
    if (ext === '.m4a' || ext === '.aac') return (size * 8) / 128000;
    return 0;
  } catch {
    return 0;
  }
}
